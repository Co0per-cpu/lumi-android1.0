// Si Android Studio ofrece actualizar estas versiones, acéptalo.
plugins {
    id("com.android.application") version "8.12.0" apply false
    id("org.jetbrains.kotlin.android") version "2.2.10" apply false
}
